//: [Previous](@previous)
import Foundation
import UIKit

/*
 1) 업캐스팅과 다운캐스팅에 대하여 설명하고,
 2) 업캐스팅과 다운캐스팅을 시도할 때 사용하는 키워드에 대해 각각 설명
 */


//업캐스팅 - 자식클래스가 부모클래스 타입으로 캐스팅 하는 것. 캐스팅 성공시 추상적으로

//다운캐스팅 - 부모클래스가 자식클래스 타입으로 캐스팅 하는 것.

// as - 업캐스팅시 사용,  var ok, let ok, optional ok, nonOptional ok,
// as? - 다운 캐스팅시 사용 옵셔널 타입, var ok, optional ok
// as! - 다운 캐스팅시 사용 반드시 값이 있을 때만 사용. var ok, let ok, nonoptional ok



/*
 TableView에서 셀을 재사용할 때 사용되는 아래의 두 메서드가 각각
 1) 언제 사용되고  2) 차이점은 무엇인지에 대하여 작성
 - dequeueReusableCell(withIdentifier:).     : cell 재사용 , 미리 identifier 선언
 - dequeueReusableCell(withIdentifier:for:).   : cell 재사용, identifier 미리 선언하지 않아도 사용 가능.
 */



/*
 safeAreaInsets  /  safeAreaLayoutGuide 의 차이점에 대해 작성
 */

//safeAreaLayoutGuide - 상단의 바와 하단의 일부를 제외한 화면

// safeAreaInsets

/*
 Strong Reference Cycle 에 대해 1) 설명하고 2) 예시 코드 작성
 */

//strong Reference Cycle (강한참조순환)
//참조 카운트가 제대로 해제되지 않고 메모리에 남아있음.
class strongClass1 {
    let second: strongCloass2
    init(second: strongCloass2) {
        self.second = second
    }
}
class strongCloass2 {
    
}



var second = strongCloass2()
var first = strongClass1(second: second)

//first = nil



/*
 Strong, Unowned, Weak 각각의 특징과 차이점에 대해 설명
 */

//strong(강한참조) - 참조 카운트 증가.
//unownde (미소유참조) - 참조카운트 증가 안함, 참조 해제시 주소 그대로 갖고있음.
//weak(약한참조) - 참조카운트 증가 안함, 참조 해제시 nil 갖음



/*
 Intrinsic Content Size란 무엇이고 어떤 특징을 가지는지 설명
 */



//: [Next](@next)
