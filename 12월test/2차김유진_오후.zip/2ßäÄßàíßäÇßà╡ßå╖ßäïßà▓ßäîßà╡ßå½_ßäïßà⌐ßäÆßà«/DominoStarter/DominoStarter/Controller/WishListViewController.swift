//
//  WishListViewController.swift
//  DominoStarter
//
//  Created by Lee on 2019/12/27.
//  Copyright © 2019 Kira. All rights reserved.
//

import UIKit

class WishListViewController: UIViewController {
  
//    private let leftBarButton = UIBarButtonItem()
//    private let rightBarButton = UIBarButtonItem()
    
    private let tableView = UITableView()
    
  override func viewDidLoad() {
    super.viewDidLoad()
    view.backgroundColor = .white
    
    attribute()
    setUpUI()
  }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        tableView.reloadData()
    }
    private func setUpUI() {
        view.addSubview(tableView)
        
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 0).isActive = true
        tableView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: 0).isActive = true
        tableView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 0).isActive = true
        tableView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: 0).isActive = true
    }
    
    private func attribute() {
        title = "Wish List"
        
        tableView.dataSource = self
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "CellID")
        tableView.rowHeight = 100
        
        let leftBarButton = UIBarButtonItem(title: "목록 지우기", style: .plain, target: self, action: #selector(didTabLeftBarButton(_:)))
        let rightBarButton = UIBarButtonItem(title: "주문", style: .plain, target: self, action: #selector(didTabRightBarButton(_:)))
        navigationItem.leftBarButtonItem = leftBarButton
        navigationItem.rightBarButtonItem = rightBarButton
        

        
    }
    
    @objc private func didTabLeftBarButton(_ sender: UIBarButtonItem) {
        
        
            print("목록지우기 버튼 클릭")
        OrderList.shard.data.removeAll()
        tableView.reloadData()
    }
    
    @objc private func didTabRightBarButton(_ sender: UIBarButtonItem) {
        
        print("주문버튼 클릭")
        let item = OrderList.shard.data
        var orderPrice = 0
        var messageString = ""
        for data in item {
            print(data)
            orderPrice += (data.price * data.count)
            messageString += ("\(data.title) - \(data.count) \n")
        }
        
        
        let orderAlert = UIAlertController(title: "결제내역", message: messageString + "결제금액 \(orderPrice)", preferredStyle: .alert)
        
        let addOrderButton = UIAlertAction(title: "주문", style: .default){ _ in
            OrderList.shard.data.removeAll()
            self.tableView.reloadData()
        }
        orderAlert.addAction(addOrderButton)
        
        let cancelButton = UIAlertAction(title: "돌아가기", style: .cancel)
        orderAlert.addAction(cancelButton)
        
        present(orderAlert, animated: true)
    }
    
}

extension WishListViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let count = OrderList.shard.data.count
        return count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CellID", for: indexPath)
        
        let data = OrderList.shard.data[indexPath.row]
        
        cell.imageView?.image = UIImage(named: data.title)
        cell.textLabel?.text = data.title
        cell.detailTextLabel?.text = "주문수량: \(data.count)"
        
        return cell
        
    }
    
    
}
