//
//  ListViewController.swift
//  DominoStarter
//
//  Created by Lee on 2019/12/27.
//  Copyright © 2019 Kira. All rights reserved.
//

import UIKit

class ListViewController: UIViewController {
  
    let tableView = UITableView()
    
  override func viewDidLoad() {
    super.viewDidLoad()
    
    view.backgroundColor = .white
    
    attribute()
    setUpUI()
    
  }
    
    private func setUpUI() {
        view.addSubview(tableView)
        
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 0).isActive = true
        tableView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: 0).isActive = true
        tableView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 0).isActive = true
        tableView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: 0).isActive = true
    }
    
    private func attribute() {
        
        title = "Domino's"
        
        tableView.rowHeight = 120
        
        
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "CellID")
        
    }
  
}

// MARK: UITableViewDataSource
extension ListViewController: UITableViewDataSource {
    
    //sectioin 몇개?
    func numberOfSections(in tableView: UITableView) -> Int {
        let count = menuData.count
        return count
    }
    //section title
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        let title = menuData[section].category
        return title
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        let count = menuData[0].category.count
        let count = menuData[section].products.count
        return count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "CellID", for: indexPath)
        
        
        let data = menuData[indexPath.section]
        let itemName = data.products[indexPath.row].name
        
        
        cell.imageView?.image = UIImage(named: itemName)
        cell.textLabel?.text = itemName
//        cell.detailTextLabel?.text = "\(data.products[indexPath.row].price) 원"
        cell.detailTextLabel?.text = "1000원"
        
        return cell
    }
    
}


// MARK: Delegate
extension ListViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //현재 셀 받아서 그거 선택하면 관련 데이터 DetailView에 뜨게.

//        indexPath.row
        let dataVC = DetailViewController()
        let sectionItem = menuData[indexPath.section]
        let itemName = sectionItem.products[indexPath.row].name
        
        let nextInfo = DetailInfo.shard
        
        nextInfo.title = itemName
        nextInfo.imageName = itemName
        nextInfo.price = sectionItem.products[indexPath.row].price
        show(dataVC, sender: nil)
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 80
    }
}
