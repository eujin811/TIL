//
//  DetailViewController.swift
//  DominoStarter
//
//  Created by Lee on 2019/12/27.
//  Copyright © 2019 Kira. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {
  
    let detailImage = UIImageView()
    let detailInfo = DetailInfo.shard
    
    private let countView = UIView()
    private let addButton = UIButton()
    private let subButton = UIButton()
    private let countLabel = UILabel()
    
    var orderInfo = Order()
    
    
  override func viewDidLoad() {
    super.viewDidLoad()
    
    view.backgroundColor = .white
    
    print("DetailViewController ViewDidLoad")
    print("imageText = \(detailInfo.imageName)")
//    detailImage.image = UIImage(named: detailInfo.imageName)
    
    orderInfo.title = detailInfo.title
    orderInfo.price = detailInfo.price
    
    attribute()
    setUpUI()
  }
    
    override func viewDidDisappear(_ animated: Bool) {
        //뷰 없어질때 orderList에 현재 order정보 넘김
        print("---DetailView DidDisappear-----")
        print(orderInfo)
        OrderList.shard.data.append(orderInfo)
    }
    private func setUpUI() {
        view.addSubview(countView)
        view.addSubview(detailImage)
        countView.addSubview(addButton)
        countView.addSubview(subButton)
        countView.addSubview(countLabel)
        
        let margin:CGFloat = 50
        let buttonSide:CGFloat = 50
        let viewHeight:CGFloat = 60
        let viewWidth:CGFloat = 300
        
        detailImage.translatesAutoresizingMaskIntoConstraints = false
        detailImage.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: 0).isActive = true
        detailImage.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: 0).isActive = true
        detailImage.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: margin).isActive = true
        detailImage.heightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.widthAnchor).isActive = true
        
        
        countView.translatesAutoresizingMaskIntoConstraints = false
        countView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -margin).isActive = true
        countView.widthAnchor.constraint(equalToConstant: viewWidth).isActive = true
        countView.heightAnchor.constraint(equalToConstant: viewHeight).isActive = true
        countView.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor).isActive = true
        
        addButton.translatesAutoresizingMaskIntoConstraints = false
        addButton.widthAnchor.constraint(equalToConstant: buttonSide).isActive = true
        addButton.heightAnchor.constraint(equalToConstant: buttonSide).isActive = true
        addButton.centerYAnchor.constraint(equalTo: countView.centerYAnchor).isActive = true
        addButton.trailingAnchor.constraint(equalTo: countView.trailingAnchor, constant: -5).isActive = true
        
        
        subButton.translatesAutoresizingMaskIntoConstraints = false
        subButton.widthAnchor.constraint(equalToConstant: buttonSide).isActive = true
        subButton.heightAnchor.constraint(equalToConstant: buttonSide).isActive = true
        subButton.centerYAnchor.constraint(equalTo: countView.centerYAnchor).isActive = true
        subButton.leadingAnchor.constraint(equalTo: countView.leadingAnchor, constant: 5).isActive = true
        
        countLabel.translatesAutoresizingMaskIntoConstraints = false
        countLabel.heightAnchor.constraint(equalToConstant: buttonSide).isActive = true
        countLabel.centerXAnchor.constraint(equalTo: countView.centerXAnchor).isActive = true
        countLabel.centerYAnchor.constraint(equalTo: countView.centerYAnchor).isActive = true
        
        
    }
    
    private func attribute() {
        title = detailInfo.title
        
        detailImage.image = UIImage(named: detailInfo.imageName)
        
        
        countView.backgroundColor = .darkGray
        
        addButton.backgroundColor = .white
        addButton.setTitleColor(.darkGray, for: .normal)
        addButton.setTitle("+", for: .normal)
        addButton.addTarget(self, action: #selector(countFunc(_:)), for: .touchUpInside)
        
        subButton.backgroundColor = .white
        subButton.setTitleColor(.darkGray, for: .normal)
        subButton.setTitle("-", for: .normal)
        subButton.addTarget(self, action: #selector(countFunc(_:)), for: .touchUpInside)
        
        countLabel.textColor = .white
        countLabel.text = "0개"
        
        
//        detailImage.image = UIImage(named: detailInfo.imageName)
//        detailImage.image = UIImage(named: "글램핑 바비큐")
        
        
    }
    
    @objc private func countFunc(_ sender:UIButton) {
        switch sender {
        case addButton:
            orderInfo.count += 1
            countLabel.text = "\(orderInfo.count)개"
        case subButton:
            if orderInfo.count != 0 {
                orderInfo.count -= 1
                countLabel.text = "\(orderInfo.count)개"
            }
            
        default:
            break
        }
    }

}
