//
//  Order.swift
//  DominoStarter
//
//  Created by YoujinMac on 2019/12/27.
//  Copyright © 2019 Kira. All rights reserved.
//

import Foundation

struct Order {
    var title: String = ""
    var price: Int = 0
    var count: Int = 0
}

class OrderList {
    static let shard = OrderList()
    
    var data = [Order]()
}
