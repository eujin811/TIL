//
//  DetailInfo.swift
//  DominoStarter
//
//  Created by YoujinMac on 2019/12/27.
//  Copyright © 2019 Kira. All rights reserved.
//

import Foundation

class DetailInfo {
    static let shard = DetailInfo()
    
    var title = ""
    var imageName = ""
    var price = 0
    
}
